JLCPCB order, full assembly (PCBA)
==================================

1. Quote page: upload tredder-revA-gerbers.zip  (do NOT unzip it)
   Layers 4 | 1.6 mm | ENIG | Via covering: Plugged
2. Same page, bottom: PCB Assembly ON -> Standard, Top side, Qty 2-5,
   Tooling holes by JLCPCB, Confirm parts placement: Yes -> NEXT -> NEXT
3. Upload page:  BOM = tredder-revA-bom-jlc.csv   CPL = tredder-revA-cpl-jlc.csv
   -> Process BOM & CPL
4. U2 (OPTIGA Trust M) is NOT in these files: JLCPCB leaves its pads bare.
   Buy SLS32AIA010MKUSON10XTMB2 from Mouser / Digi-Key and solder it yourself.
5. Placement preview: rotations are already corrected for JLCPCB's footprints.
   Still check pin 1 / polarity of U1, U3, Q1-Q5 and D1, then Save to Cart

Details: FAB_NOTES.md
