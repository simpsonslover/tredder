tredder rev A: everything needed to make the board
=====================================================

1_order_JLCPCB/       Order the board, fully assembled, at jlcpcb.com.
                      Follow 1_order_JLCPCB/READ_ME_FIRST.txt step by step.
                      The placement file (CPL) is already corrected for JLCPCB's
                      own footprints (rotations measured per part).

2_other_factories/    For PCBWay or another assembler: same Gerbers, a BOM by
                      manufacturer part number, and KiCad's plain placement file.

3_buy_separately/     PARTS_LIST.md: what is NOT on the board and you buy yourself
                      (2.0in ST7789 display module, 503035 LiPo with protection and
                      JST-PH lead, foam tape, M2 screws, microSD card, USB-C cable).

4_checks_and_docs/    Schematic (PDF), board renders, FAB_NOTES.md, the independent
                      check of the Gerber files (gerber_drc.md), and the hardware
                      README with the checklist before ordering (section 6) and the
                      bring-up / test plan (section 8).

5_3d_models/          STEP models: the assembled board with display and battery (for
                      designing the case) and the simplified simulation version.

6_kicad_project/      The editable design. Open wallet.kicad_pro in KiCad 10.

7_fusion/             For Autodesk Fusion: the electronics import copy (KiCad 9
                      format) and the simulation script package (see FUSION_SIM.md).

BEFORE YOU PAY (hardware README section 6):
  1. Buy the display module first; its pin order must be
     GND VCC SCL SDA RES DC CS BLK on J4, about 60 x 36 mm.
  2. Check the OPTIGA (U2) footprint against Infineon's package drawing.
  3. Check the DPDT power switch commons (pins 2 and 5) and the microSD
     card-detect direction against their datasheets.
  4. Look over the routed tracks yourself in KiCad.
  5. On JLCPCB: 4 layers, every BOM line in stock, Global Sourcing for U2,
     and look at the placement preview (pin 1 / polarity of U1, U2, U3, Q1-Q5, D1).
  6. Before plugging the battery in: check its lead polarity (pin 1 = BAT+).
