JLCPCB order, full assembly (PCBA)
==================================

1. Quote page: upload tredder-revA-gerbers.zip  (do NOT unzip it)
   Layers 4 | 1.6 mm | ENIG | Via covering: Tented
2. Same page, bottom: PCB Assembly ON -> Standard, Top side, Qty 2-5,
   Tooling holes by JLCPCB, Confirm parts placement: Yes -> NEXT -> NEXT
3. Upload page:  BOM = tredder-revA-bom-jlc.csv   CPL = tredder-revA-cpl-jlc.csv
   -> Process BOM & CPL
4. U2 (OPTIGA Trust M, SLS32AIA010MKUSON10XTMA2): choose Global Sourcing
5. Check the placement preview (rotations), then Save to Cart

Details: FAB_NOTES.md
